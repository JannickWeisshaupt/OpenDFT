# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

from tvtk.tvtk_classes.glyph3d_mapper import Glyph3DMapper


class OpenGLGlyph3DMapper(Glyph3DMapper):
    """
    OpenGLGlyph3DMapper - OpenGLGlyph3D on the GPU.
    
    Superclass: Glyph3DMapper
    
    Do the same job than Glyph3D but on the GPU. For this reason, it
    is a mapper not a PolyDataAlgorithm. Also, some methods of
    OpenGLGlyph3D don't make sense in OpenGLGlyph3DMapper:
    generate_point_ids, old-style set_source, point_ids_name, is_point_visible.
    
    @sa
    OpenGLGlyph3D
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkOpenGLGlyph3DMapper, obj, update, **traits)
    
    def _get_input(self):
        return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input, help=\
        """
        Get the input as a DataSet.  This method is overridden in the
        specialized mapper classes to return more specific data types.
        """
    )

    _updateable_traits_ = \
    (('progress_text', 'GetProgressText'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('array_component', 'GetArrayComponent'),
    ('static', 'GetStatic'), ('masking', 'GetMasking'),
    ('use_lookup_table_scalar_range', 'GetUseLookupTableScalarRange'),
    ('orient', 'GetOrient'), ('progress', 'GetProgress'),
    ('selection_color_id', 'GetSelectionColorId'), ('scale_factor',
    'GetScaleFactor'), ('use_source_table_tree', 'GetUseSourceTableTree'),
    ('color_mode', 'GetColorMode'), ('resolve_coincident_topology',
    'GetResolveCoincidentTopology'), ('reference_count',
    'GetReferenceCount'), ('debug', 'GetDebug'), ('clamping',
    'GetClamping'), ('abort_execute', 'GetAbortExecute'), ('array_name',
    'GetArrayName'), ('render_time', 'GetRenderTime'),
    ('orientation_mode', 'GetOrientationMode'),
    ('resolve_coincident_topology_z_shift',
    'GetResolveCoincidentTopologyZShift'), ('release_data_flag',
    'GetReleaseDataFlag'), ('scale_mode', 'GetScaleMode'),
    ('resolve_coincident_topology_polygon_offset_faces',
    'GetResolveCoincidentTopologyPolygonOffsetFaces'), ('scaling',
    'GetScaling'), ('array_id', 'GetArrayId'), ('scalar_visibility',
    'GetScalarVisibility'), ('source_indexing', 'GetSourceIndexing'),
    ('use_selection_ids', 'GetUseSelectionIds'), ('field_data_tuple_id',
    'GetFieldDataTupleId'), ('interpolate_scalars_before_mapping',
    'GetInterpolateScalarsBeforeMapping'), ('scalar_range',
    'GetScalarRange'), ('scalar_mode', 'GetScalarMode'), ('range',
    'GetRange'), ('array_access_mode', 'GetArrayAccessMode'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'clamping', 'debug', 'global_warning_display',
    'interpolate_scalars_before_mapping', 'masking', 'orient',
    'release_data_flag', 'scalar_visibility', 'scaling',
    'source_indexing', 'static', 'use_lookup_table_scalar_range',
    'use_selection_ids', 'use_source_table_tree', 'color_mode',
    'orientation_mode', 'resolve_coincident_topology', 'scalar_mode',
    'scale_mode', 'array_access_mode', 'array_component', 'array_id',
    'array_name', 'field_data_tuple_id', 'progress_text', 'range',
    'render_time', 'resolve_coincident_topology_polygon_offset_faces',
    'resolve_coincident_topology_z_shift', 'scalar_range', 'scale_factor',
    'selection_color_id'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(OpenGLGlyph3DMapper, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit OpenGLGlyph3DMapper properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['clamping', 'interpolate_scalars_before_mapping', 'masking',
            'orient', 'scalar_visibility', 'scaling', 'source_indexing', 'static',
            'use_lookup_table_scalar_range', 'use_selection_ids',
            'use_source_table_tree'], ['color_mode', 'orientation_mode',
            'resolve_coincident_topology', 'scalar_mode', 'scale_mode'],
            ['array_access_mode', 'array_component', 'array_id', 'array_name',
            'field_data_tuple_id', 'range', 'render_time',
            'resolve_coincident_topology_polygon_offset_faces',
            'resolve_coincident_topology_z_shift', 'scalar_range', 'scale_factor',
            'selection_color_id']),
            title='Edit OpenGLGlyph3DMapper properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit OpenGLGlyph3DMapper properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

